package com.example.soccercounter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    int firstTeamRed = 0;
    int firstTeamYellow = 0;
    int firstTeamScore = 0;

    int secondTeamRed = 0;
    int secondTeamYellow = 0;
    int secondTeamScore = 0;

    //final Button button = (Button) findViewById(R.id.red_card);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void redCardA(View v) {
        firstTeamRed++;
        displayForTeamA(firstTeamScore, firstTeamYellow, firstTeamRed);
    }

    public void YellowCardA(View v) {
        firstTeamYellow++;
        displayForTeamA(firstTeamScore, firstTeamYellow, firstTeamRed);
    }

    public void ScoreA(View v) {
        firstTeamScore++;
        displayForTeamA(firstTeamScore, firstTeamYellow, firstTeamRed);
    }

    public void redCardB(View v) {

        secondTeamRed++;
        displayForTeamB(secondTeamScore, secondTeamYellow, secondTeamRed);
    }

    public void YellowCardB(View v) {

        secondTeamYellow++;
        displayForTeamB(secondTeamScore, secondTeamYellow, secondTeamRed);
    }

    public void ScoreB(View v) {

        secondTeamScore++;
        displayForTeamB(secondTeamScore, secondTeamYellow, secondTeamRed);
    }

    public void displayForTeamA(int score, int yellow, int red) {
        TextView teamAGoal = (TextView) findViewById(R.id.TeamAGoal);
        teamAGoal.setText(String.valueOf(score));

        TextView teamAYellow = (TextView) findViewById(R.id.TeamAYellow);
        teamAYellow.setText(String.valueOf(yellow));

        TextView teamARed = (TextView) findViewById(R.id.TeamARed);
        teamARed.setText(String.valueOf(red));
    }

    public void displayForTeamB(int score, int yellow, int red) {
        TextView TeamBGoal = (TextView) findViewById(R.id.TeamBGoal);
        TeamBGoal.setText(String.valueOf(score));

        TextView TeamBYellow = (TextView) findViewById(R.id.TeamBYellow);
        TeamBYellow.setText(String.valueOf(yellow));

        TextView TeamBRed = (TextView) findViewById(R.id.TeamBRed);
        TeamBRed.setText(String.valueOf(red));
    }

    public void ResetStats(View v) {
        firstTeamRed = 0;
        firstTeamYellow = 0;
        firstTeamScore = 0;

        secondTeamRed = 0;
        secondTeamYellow = 0;
        secondTeamScore = 0;
        displayForTeamA(firstTeamScore,firstTeamYellow,firstTeamRed);
        displayForTeamB(secondTeamScore,secondTeamYellow,secondTeamRed);
    }


}
